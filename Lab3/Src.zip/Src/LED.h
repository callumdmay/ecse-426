#ifndef LED
#define LED



void LEDSet(int diff[2]);
#endif
