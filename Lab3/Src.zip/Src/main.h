#ifndef MAIN_H
#define MAIN_H
#include "keypad.h"

void process_switch(struct keypadState *kpState);

#endif
