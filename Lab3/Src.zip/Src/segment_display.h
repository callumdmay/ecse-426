#ifndef H_SEGMENT_DISPLAY
#define H_SEGMENT_DISPLAY

void updateSegmentDisplay(char *num_buffer);
void initSegmentDisplay(void);
#endif
