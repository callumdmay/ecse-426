#ifndef SYSTEM_CLOCK_TICK
#define SYSTEM_CLOCK_TICK

void SystemClock_Config(void);
	
#endif
